﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sky_picture
{
    internal delegate void EventInfoFileBandeauHandler(ref string TexteModif);

    internal partial class InfoFileBandeau : UserControl
    {
        internal event EventInfoFileBandeauHandler RenameImage = null;
        private bool SelectTextBox1_M = false;
        private bool CanRename = true;

        internal InfoFileBandeau()
        {
            InitializeComponent();
        }

        internal void UpdateData(string FileName, string Resolution, string FormatPx)
        {
            CanRename = false;
            textBox1.Text = Path.GetFileNameWithoutExtension(FileName);
            label2.Text = "Chemin de fichier : " + FileName;
            toolTip1.SetToolTip(this.label2, FileName);
            label3.Text = "Taille : " + (new FileInfo(FileName).Length / 1000) + " ko";
            label4.Text = "Type de fichier : " + Path.GetExtension(FileName);
            label5.Text = "Date de création : " + File.GetCreationTime(FileName);
            label6.Text = "Résolution : " + Resolution;
            label7.Text = "Profondeur de couleur : " + FormatPx;
            CanRename = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != string.Empty && CanRename == true)
            {
                ExecuterEvenementRenameImage(textBox1.Text);
            }
        }

        protected virtual void ExecuterEvenementRenameImage(string text)
        {
            if (RenameImage != null)
            {
                RenameImage(ref text);
            }
        }

        internal bool SelectTextBox1
        {
            get
            {
                return SelectTextBox1_M;
            }
            set
            {
                SelectTextBox1_M = value;

                if (value == true)
                {
                    textBox1.Select();
                    textBox1.SelectAll();
                }
                else
                {
                    textBox1.DeselectAll();
                    label1.Select();
                }
            }
        }

        internal void DeselectTextBox1()
        {
            textBox1.DeselectAll();
            this.Select();
        }
    }
}
