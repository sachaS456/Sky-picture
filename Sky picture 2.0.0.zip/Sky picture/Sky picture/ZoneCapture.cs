﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_picture
{
    internal partial class ZoneCapture : Form
    {
        private Image Image = null;

        internal ZoneCapture()
        {
            InitializeComponent();
        }

        private void ZoneCapture_MouseMove(object sender, MouseEventArgs e)
        {
            if (panel1.Visible == true)
            {
                panel1.Size = new Size(e.X - panel1.Location.X, e.Y - panel1.Location.Y);
            }
        }

        private void ZoneCapture_MouseDown(object sender, MouseEventArgs e)
        {
            panel1.Location = new Point(e.X, e.Y);
            panel1.Visible = true;
        }

        internal Image ImageCapturee
        {
            get
            {
                return Image;
            }
        }

        private void ZoneCapture_MouseUp(object sender, MouseEventArgs e)
        {
            panel1.Visible = false;
            this.Opacity = 0;
            Image = CaptureScreen(ref panel1);
            this.Close();
        }

        private Bitmap CaptureScreen(ref Panel rect)
        {
            Bitmap bitmap = new Bitmap(rect.Width, rect.Height, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.CopyFromScreen(rect.Left, rect.Top, 0, 0, rect.Size, CopyPixelOperation.SourceCopy);
            }

            return bitmap;
        }
    }
}
