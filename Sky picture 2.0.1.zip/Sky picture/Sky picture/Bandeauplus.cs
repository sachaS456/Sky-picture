﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_picture
{
    internal delegate void EventButtonClickHandler();

    internal partial class Bandeauplus : UserControl
    {
        internal event EventButtonClickHandler RemoveImage = null;
        internal event EventButtonClickHandler RenameImage = null;
        internal event EventButtonClickHandler DefinirFondEcranImage = null;
        internal event EventButtonClickHandler PivoterImage = null;
        internal event EventButtonClickHandler CaptureEcran = null;

        internal Bandeauplus()
        {
            InitializeComponent();
        }

        protected virtual void ExecuterEvenementRemoveImage()
        {
            if (RemoveImage != null)
            {
                RemoveImage();
            }
        }

        protected virtual void ExecuterEvenementRenameImage()
        {
            if (RenameImage != null)
            {
                RenameImage();
            }
        }

        protected virtual void ExecuterEvenementDefinirFondEcranImage()
        {
            if (DefinirFondEcranImage != null)
            {
                DefinirFondEcranImage();
            }
        }

        protected virtual void ExecuterEvenementPivoterImage()
        {
            if (PivoterImage != null)
            {
                PivoterImage();
            }
        }

        protected virtual void ExecuterEvenementCaptureEcran()
        {
            if (CaptureEcran != null)
            {
                CaptureEcran();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ExecuterEvenementCaptureEcran();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExecuterEvenementDefinirFondEcranImage();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExecuterEvenementRenameImage();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ExecuterEvenementRemoveImage();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ExecuterEvenementPivoterImage();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // à propos
            new InfoApp().ShowDialog();
        }
    }
}
