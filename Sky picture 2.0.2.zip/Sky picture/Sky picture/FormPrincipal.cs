﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Drawing.Printing;

namespace Sky_picture
{
    internal partial class FormPrincipal : Form
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SystemParametersInfo(sbyte uAction, sbyte uParam, string lpvParam, sbyte fuWinIni);
        private bool FormCache = false;
        private int Coter = 0;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private string FilePathPicture = string.Empty;
        private bool BandeauCache = true;
        private bool InfoBandeauCache = true;
        private Bandeauplus bandeauplus1 = new Bandeauplus();
        private List<string> PathImageListe = new List<string>();
        private InfoFileBandeau InfoFileBandeau1 = new InfoFileBandeau();
        private int Timer5_Index = 0;
        private int MouseLocX = 0;
        private int MouseLocY = 0;
        private bool ButtonTouch = false;
        private const int MiniLargeForm = 443;
        private const int MiniHautForm = 298;
        private bool CaptureEcranChagee = false;

        internal FormPrincipal()
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;
            button11.Parent = pictureBox2;
            button12.Parent = pictureBox2;
            this.panel1.Controls.Add(this.bandeauplus1);
            bandeauplus1.Location = new Point(pictureBox2.Size.Width - (bandeauplus1.Size.Width + 2), 2 - bandeauplus1.Size.Height);
            bandeauplus1.BorderStyle = BorderStyle.FixedSingle;
            bandeauplus1.Visible = false;
            bandeauplus1.Parent = pictureBox2;
            bandeauplus1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            bandeauplus1.CaptureEcran += new EventButtonClickHandler(CaptureEcran);
            bandeauplus1.RemoveImage += new EventButtonClickHandler(RemoveImage);
            bandeauplus1.RenameImage += new EventButtonClickHandler(RenameImage);
            bandeauplus1.PivoterImage += new EventButtonClickHandler(PivoterImage);
            bandeauplus1.DefinirFondEcranImage += new EventButtonClickHandler(DefinirFondEcran);
            InfoFileBandeau1.RenameImage += new EventInfoFileBandeauHandler(RenameImage);
            InfoFileBandeau1.Size = new Size(InfoFileBandeau1.Size.Width, pictureBox2.Size.Height);
            InfoFileBandeau1.Location = new Point(0 - InfoFileBandeau1.Size.Width, 0);
            InfoFileBandeau1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom;
            InfoFileBandeau1.Visible = false;
            panel1.Controls.Add(InfoFileBandeau1);
            InfoFileBandeau1.Parent = pictureBox2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    Environment.Exit(0);
                }
            }
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }


        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void FormPrincipal_MouseDown(object sender, MouseEventArgs e)
        {
            if (BandeauCache == false)
            {
                timer3.Enabled = true;
                bandeauplus1.BringToFront();
            }

            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }

            if (this.Cursor != Cursors.Default)
            {
                /// Coin :

                if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas droite
                    Coter = 8;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas gauche
                    Coter = 7;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X >= this.Size.Width - 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut droite
                    Coter = 5;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut gauche
                    Coter = 6;
                    timer2.Enabled = true;
                    return;
                }

                /// cotée :

                if (e.X == 0)
                {
                    // agrandit ou réduit coté gauche

                    Coter = 2;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X == this.Size.Width - 1)
                {
                    // agrandit ou réduit coté droite

                    Coter = 1;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == this.Size.Height - 1)
                {
                    // agrandit ou réduit coté bas
                    Coter = 4;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == 0)
                {
                    // agrandit ou réduit coté haut
                    Coter = 3;
                    timer2.Enabled = true;
                    return;
                }
            }
        }

        private void FormPrincipal_MouseUp(object sender, MouseEventArgs e)
        {
            timer2.Enabled = false;
            Coter = 0;
            FormDeplace = false;
        }

        private void FormPrincipal_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }

            this.Cursor = Cursors.Default;
            button2.Cursor = Cursors.Default;

            if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas droite
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X <= 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas gauche
                this.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X <= 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut gauche
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X == this.Size.Width - 1)
            {
                // agrandit ou réduit coté droite
                this.Cursor = Cursors.SizeWE;
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.X == 0)
            {
                // agrandit ou réduit coté gauche
                this.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == this.Size.Height - 1)
            {
                // agrandit ou réduit coté bas
                this.Cursor = Cursors.SizeNS;
                return;
            }

            if (e.Y == 0)
            {
                // agrandit ou réduit coté haut
                this.Cursor = Cursors.SizeNS;
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (Coter)
            {
                case 1:  // côtée droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 2: // côtée gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 3:  // côtée haut
                    if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 4:  // côtée bas
                    if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 5:  // coin haut droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 6:  // coin haut gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(MousePosition.X, MousePosition.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 7:  // coin bas gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MousePosition.Y - this.Location.Y);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 8:  // coin bas droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MousePosition.Y - this.Location.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;
            }
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Cursor = Cursors.Default;


            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                button1.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X == button1.Size.Width - 1)
            {
                // droite
                button1.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == 1)
            {
                // haut
                button1.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                Coter = 5;
                timer2.Enabled = true;
                return;
            }

            if (e.X == button1.Size.Width - 2)
            {
                // agrandit ou réduit coté droite

                Coter = 1;
                timer2.Enabled = true;
                return;
            }

            if (e.Y == 1)
            {
                // agrandit ou réduit coté haut
                Coter = 3;
                timer2.Enabled = true;
                return;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (CaptureEcranChagee == true)
            {
                switch (MessageBox.Show("Voulez vous enregistrer votre capture d'écran?", "Sky picture", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        EnregistrerImage();
                        break;

                    case DialogResult.Cancel:
                        return;
                }
            }
            timer1.Enabled = true;
        }

        private void panel1_MouseEnter(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox2_MouseEnter(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Images | *.jpeg; *.png; *.jpg; *.bmp; *.ico; *.gif; *.tiff |Tous les fichiers| *.*";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (FilePathPicture != string.Empty)
                    {
                        pictureBox2.Image.Dispose();
                    }
                    pictureBox2.Image = Image.FromFile(dialog.FileName);
                    FilePathPicture = dialog.FileName;
                    CaptureEcranChagee = false;
                    PictureBoxManager();
                    NewListeFile();
                }
                catch
                {
                    MessageBox.Show("Erreur, ce fichier est non pris en charge ou n'est pas une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            if (Environment.GetCommandLineArgs().Last() != Application.ExecutablePath && Environment.GetCommandLineArgs().Last() != Application.StartupPath + "Sky picture.dll")
            {
                try
                {
                    pictureBox2.Image = Image.FromFile(Environment.GetCommandLineArgs().Last());
                    FilePathPicture = Environment.GetCommandLineArgs().Last();
                    PictureBoxManager();
                    NewListeFile();
                }
                catch
                {
                    MessageBox.Show("Erreur, ce fichier est non pris en charge ou n'est pas une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void PictureBoxManager()
        {
            if (FilePathPicture != string.Empty || CaptureEcranChagee == true)
            {
                if (pictureBox2.Size.Width <= pictureBox2.Image.Width || pictureBox2.Size.Height <= pictureBox2.Image.Height)
                {
                    pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            EnregistrerImage();
        }

        private void EnregistrerImage()
        {
            if (CaptureEcranChagee == true)
            {
                SaveFileDialog dialog = new SaveFileDialog();
                dialog.Filter = "Images | *.png; *.jpeg; *.jpg; *.bmp; *.ico; *.gif; *.tiff |Tous les fichiers| *.*";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        pictureBox2.Image.Save(dialog.FileName);
                    }
                    catch
                    {
                        MessageBox.Show("Impossible d'enregistrer l'image une erreur est survenue!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (CaptureEcranChagee == true)
                    {
                        CaptureEcranChagee = false;
                        FilePathPicture = dialog.FileName;
                        NewListeFile();
                    }
                }
            }
            else if (FilePathPicture != string.Empty)
            {
                try
                {
                    pictureBox2.Image.Save(FilePathPicture);
                }
                catch
                {
                    MessageBox.Show("Impossible d'enregistrer l'image une erreur est survenue!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Veuillez charger une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void pictureBox2_Resize(object sender, EventArgs e)
        {
            PictureBoxManager();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer3.Enabled = true;
            bandeauplus1.BringToFront();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (BandeauCache == false)
            {
                // cacher bandeau
                bandeauplus1.Location = new Point(bandeauplus1.Location.X, bandeauplus1.Location.Y - 15);

                if (bandeauplus1.Location.Y < 2 - bandeauplus1.Size.Height)
                {
                    timer3.Enabled = false;
                    bandeauplus1.Visible = false;
                    BandeauCache = true;
                }
            }
            else
            {
                // montrer bandeau
                if (bandeauplus1.Location.Y >= -15)
                {
                    bandeauplus1.Location = new Point(bandeauplus1.Location.X, -15);
                    timer3.Enabled = false;
                    BandeauCache = false;
                }

                bandeauplus1.Visible = true;
                bandeauplus1.Location = new Point(bandeauplus1.Location.X, bandeauplus1.Location.Y + 15);
            }
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (BandeauCache == false)
            {
                timer3.Enabled = true;
                bandeauplus1.BringToFront();
            }

            if (InfoBandeauCache == false)
            {
                timer4.Enabled = true;
                bandeauplus1.BringToFront();
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (BandeauCache == false)
            {
                timer3.Enabled = true;
                bandeauplus1.BringToFront();
            }

            if (InfoBandeauCache == false)
            {
                timer4.Enabled = true;
                bandeauplus1.BringToFront();
            }
        }

        private void CaptureEcran()
        {
            this.Visible = false;
            ZoneCapture Capture = new ZoneCapture();
            Capture.ShowDialog();
            pictureBox2.Image = Capture.ImageCapturee;
            FilePathPicture = string.Empty;
            CaptureEcranChagee = true;
            PictureBoxManager();
            this.Visible = true;
        }

        private void RemoveImage()
        {
            if (MessageBox.Show("Êtes vous sûre de vouloir supprimer cette image?", "Sky picture", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                if (FilePathPicture != string.Empty)
                {
                    try
                    {
                        pictureBox2.Image.Dispose();
                        File.Delete(FilePathPicture);
                        NewListeFile();
                    }
                    catch
                    {
                        MessageBox.Show("Une est survenue! Impossible de supprimer le fichier.", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    if (PathImageListe.Count() == 0)
                    {
                        Environment.Exit(0);
                        return;
                    }
                    ImageDroite();
                    PictureBoxManager();
                }
                else
                {
                    MessageBox.Show("Veuillez charger une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void RenameImage()
        {
            InfoFileBandeau1.BringToFront();
            timer4.Enabled = true;
            InfoFileBandeau1.Select();
            InfoFileBandeau1.SelectTextBox1 = true;

            if (FilePathPicture != string.Empty)
            {
                InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                    pictureBox2.Image.PixelFormat.ToString());
            }
        }

        private void DefinirFondEcran()
        {
            if (FilePathPicture == string.Empty || CaptureEcranChagee == true)
            {
                MessageBox.Show("Veuillez charger une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                SystemParametersInfo(20, 0, FilePathPicture, 0x1 | 0x2);
            }
        }

        private void PivoterImage()
        {
            if (FilePathPicture != string.Empty || CaptureEcranChagee == true)
            {
                pictureBox2.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
                pictureBox2.SizeMode = PictureBoxSizeMode.Normal;
                PictureBoxManager();
            }
            else
            {
                MessageBox.Show("Veuillez charger une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void NewListeFile()
        {
            PathImageListe.Clear();

            foreach (string i in Directory.EnumerateFiles(Path.GetDirectoryName(FilePathPicture)))
            {
                if (Path.GetExtension(i) != ".exe" || Path.GetExtension(i) != ".dll" || Path.GetExtension(i) != ".txt" || Path.GetExtension(i) != ".sys" || Path.GetExtension(i) != ".lnk")
                {
                    PathImageListe.Add(i);
                }
            }
        }

        private void ImageDroite()
        {
            List<string> FileList = new List<string>(Directory.EnumerateFiles(Path.GetDirectoryName(FilePathPicture)));

            do
            {
                int index = 0;
                foreach (string i in FileList)
                {
                    if (i == FilePathPicture)
                    {
                        break;
                    }
                    index++;
                }

                if (index < FileList.Count() - 1)
                {
                    FilePathPicture = FileList[index + 1];
                }
                else
                {
                    FilePathPicture = FileList[0];
                }
            }
            while (IsPicture(ref FilePathPicture) == false);

            pictureBox2.Image.Dispose();
            pictureBox2.Image = Image.FromFile(FilePathPicture);

            FileList.Clear();
            FileList = null;
        }

        private void ImageGauche()
        {
            List<string> FileList = new List<string>(Directory.EnumerateFiles(Path.GetDirectoryName(FilePathPicture)));

            do
            {
                int index = 0;
                foreach (string i in FileList)
                {
                    if (i == FilePathPicture)
                    {
                        break;
                    }
                    index++;
                }

                if (index > 0)
                {
                    FilePathPicture = FileList[index - 1];
                }
                else
                {
                    FilePathPicture = FileList[FileList.Count() - 1];
                }
            }
            while (IsPicture(ref FilePathPicture) == false);

            pictureBox2.Image.Dispose();
            pictureBox2.Image = Image.FromFile(FilePathPicture);

            FileList.Clear();
            FileList = null;
        }

        private bool IsPicture(ref string FilePath)
        {
            Image test;

            try
            {
                test = Image.FromFile(FilePath);
                test.Dispose();
                test = null;
                return true;
            }
            catch
            {
                test = null;
                return false;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (FilePathPicture != string.Empty)
            {
                ImageDroite();
                PictureBoxManager();
                InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                     pictureBox2.Image.PixelFormat.ToString());
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (FilePathPicture != string.Empty)
            {
                ImageGauche();
                PictureBoxManager();
                InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                     pictureBox2.Image.PixelFormat.ToString());
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // imprimer image
            if (FilePathPicture != string.Empty || CaptureEcranChagee == true)
            {
                PrintDialog DialogPrint = new PrintDialog();
                PrintDocument doc = new PrintDocument();

                doc.PrintPage += docPage;
                DialogPrint.Document = doc;

                if (DialogPrint.ShowDialog() == DialogResult.OK)
                {
                    doc.Print();
                }
            }
            else
            {
                MessageBox.Show("Veuillez charger une image!", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void docPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(pictureBox2.Image, pictureBox2.Bounds);
        }

        private void RenameImage(ref string NewName)
        {
            if (FilePathPicture != string.Empty)
            {
                try
                {
                    NewName = Path.GetDirectoryName(FilePathPicture) + @"\" + NewName + Path.GetExtension(FilePathPicture);

                    if (File.Exists(NewName))
                    {
                        if (MessageBox.Show("Un fichier est déjà existant voulez vous le remplacer?", "Sky multi", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                        {
                            InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                                pictureBox2.Image.PixelFormat.ToString());
                            return;
                        }
                        else
                        {
                            try
                            {
                                File.Delete(NewName);
                            }
                            catch
                            {
                                MessageBox.Show("Une erreur est survenue! Impossible de remplacer le fichier.", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                                     pictureBox2.Image.PixelFormat.ToString());
                                return;
                            }
                        }
                    }

                    pictureBox2.Image.Dispose();
                    File.Move(FilePathPicture, NewName);
                    pictureBox2.Image = Image.FromFile(NewName);
                    FilePathPicture = NewName;
                    NewListeFile();
                }
                catch
                {
                    pictureBox2.Image = Image.FromFile(FilePathPicture);
                    MessageBox.Show("Une erreur est survenue! Impossible de renommer l'image.", "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                         pictureBox2.Image.PixelFormat.ToString());
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            InfoFileBandeau1.BringToFront();
            timer4.Enabled = true;

            if (FilePathPicture != string.Empty)
            {
                InfoFileBandeau1.UpdateData(FilePathPicture, pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                    pictureBox2.Image.PixelFormat.ToString(), false);
            }
            else if (CaptureEcranChagee == true)
            {
                InfoFileBandeau1.UpdateData("", pictureBox2.Image.Width + " x " + pictureBox2.Image.Height,
                    pictureBox2.Image.PixelFormat.ToString(), true);
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (InfoBandeauCache == false)  // si contrôle est visible
            {
                // cache contrôle
                InfoFileBandeau1.Location = new Point(InfoFileBandeau1.Location.X - 15, 0);

                if (InfoFileBandeau1.Location.X <= 0 - InfoFileBandeau1.Size.Width)
                {
                    timer4.Enabled = false;
                    InfoFileBandeau1.Visible = false;
                    InfoFileBandeau1.Location = new Point(0 - InfoFileBandeau1.Size.Width, 0);
                    InfoBandeauCache = true;
                    InfoFileBandeau1.SelectTextBox1 = false;
                }
            }
            else
            {
                // montre contrôle
                InfoFileBandeau1.Visible = true;
                InfoFileBandeau1.Location = new Point(InfoFileBandeau1.Location.X + 15, 0);

                if (InfoFileBandeau1.Location.X >= -15)
                {
                    timer4.Enabled = false;
                    InfoFileBandeau1.Location = new Point(0, 0);
                    InfoBandeauCache = false;

                    if (InfoFileBandeau1.SelectTextBox1 == true)
                    {
                        InfoFileBandeau1.SelectTextBox1 = true;
                    }
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // Pleine écra
            if (panel1.Size == this.Size)
            {
                // normal screen
                this.WindowState = FormWindowState.Normal;
                panel1.Size = new Size(this.Size.Width - 4, this.Size.Height - 29);
                panel1.Location = new Point(2, 27);
                button1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                pictureBox1.Visible = true;
                label1.Visible = true;
            }
            else
            {
                // full screen
                panel1.Size = this.Size;
                panel1.Location = new Point(0, 0);
                this.WindowState = FormWindowState.Maximized;
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                pictureBox1.Visible = false;
                label1.Visible = false;
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (Timer5_Index >= 60 && ButtonTouch == false)
            {
                if (this.Cursor == Cursors.Default && button11.Visible == true)
                {
                    Cursor.Hide();
                }

                button11.Visible = false;
                button12.Visible = false;
            }

            if (MousePosition.X != MouseLocX && MouseLocY != MousePosition.Y || ButtonTouch == true)
            {
                if (button11.Visible == false)
                {
                    Cursor.Show();
                }

                Timer5_Index = 0;
                button11.Visible = true;
                button12.Visible = true;
            }

            MouseLocX = MousePosition.X;
            MouseLocY = MousePosition.Y;
            Timer5_Index++;
        }

        private void ButtonTouchF(object sender, EventArgs e)
        {
            ButtonTouch = true;
        }

        private void ButtonNoTouchF(object sender, EventArgs e)
        {
            ButtonTouch = false;
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            if (FilePathPicture != string.Empty)
            {
                if (FilePathPicture != Path.GetFileName(FilePathPicture))
                {
                    label1.Text = "Sky picture - " + Path.GetFileName(FilePathPicture);
                }
            }
        }
    }
}
