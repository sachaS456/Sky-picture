using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Principal;
using Sky_updater;
using System.Threading;

namespace Sky_picture
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (IsElevated() == false)
            {
                Thread thread = new Thread(new ThreadStart(CheckUpdate));
                thread.Priority = ThreadPriority.Highest;
                thread.Start();

                Application.Run(new FormPrincipal());
            }
            else
            {
                MessageBox.Show("Cette application refuse les autorisations administrateur pour votre s�curit�! Veuillez relancer l'application sans les privill�ges administrateur.",
                    "Sky picture", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Environment.Exit(0);
            }
        }

        private static void CheckUpdate()
        {
            Update.CheckUpdate("Sky picture", Application.ProductVersion);
        }

        private static bool IsElevated()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            return id.Owner != id.User;
        }
    }
}
